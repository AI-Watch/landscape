File "AITES2019_Players_and_RnD.csv"

_VARIABLE_	_DESCRIPTION_	
GEO_AREA	Name of the country (apart from EU28 that is considered as a single area) where players are located. Location does not imply nationality	
GEO_AREA_CODE	"Code of the country (ISO2, except United Kingdom and Greece, that follow Eurostat code)"	
MACRO_GEO_AREA	Geographic macro area where the players are located
CONTINENT	Geographic continent where the players are located	
TIME_PERIOD	Time period considered for the analysis	
NPLAYER	"Number of players located in the area. There are three types of players: firms, research institutes and governmental institutions"	
NFIRM	Number of firms	
NGOV	Number of governmental institutions	
NRES	Number of research institutes	
NPLAYER_PAT	Number of players with at least one patent application filed (as applicant)	
NFIRM_PAT	Number of firms with at least one patent application filed (as applicant)	
NPAT	Number of patent applications filed (patents are counted with fractional counting for all co-applicants)	
NPAT_AVG_PL	Average number of patent applications filed by the players with at least one patent	
NPAT_AVG_F	Average number of patent applications filed by firms with at least one patent application	
NPLAYER_RD	Number of players active in R&D (i.e. players with at least one patent application or one frontier research publication)	
NFIRM_RD	Number of firms active in R&D (i.e. firms with at least one patent application or one frontier research publication)	
NRES_RD	Number of research institutes active in R&D (i.e. firms with at least one patent application or one frontier research publication)	
NPLAYER_PUB	Number of players with at least one frontier research publication	
GDP_BN_EURPPS	Gross Domestic Product (GDP) in billion EUR PPS	
GDP_YEAR	Year of reference of the GDP	
BERD_M_EURPPS	Business Enterprise R&D Expenditure (BERD) in million EUR PPS	
BERD_YEAR	Year of reference of the BERD	
GERD_M_EURPPS	Gross domestic expenditure on R&D (GERD) in million EUR PPS	
GERD_YEAR	Year of reference of the GERD	
POP_M	Population in million persons	
POP_YEAR	Year of reference of Population	
NPLAYER_GDP	Ratio: Number of players / GDP in billion EUR PPS	
NPLAYER_BERD	Ratio: Number of players / BERD in million EUR PPS	
NPLAYER_GERD	Ratio: Number of players / GERD in million EUR PPS	
RDSCORE_SUM	"RD score: sum (by player in the area) of: number of patents (in fractional counting and normalised in interval [0,1]) + number of publications (in fractional counting and normalised in interval [0,1]). EU projects are not considered.	
RDSCORE_AVG	"RD score: average (by player in the area) of: number of patents (in fractional counting and normalised in interval [0,1]) + number of publications (in fractional counting and normalised in interval [0,1]). EU projects are not considered.	
RDSCORE_SUM_EUPR	RD score: sum (by player in the area) of: number of patents (in fractional counting and normalised in interval [0,1]) + number of publications (in fractional counting and normalised in interval [0,1]) + number of EU funded projects (in fractional counting and normalised in interval [0,1])	
RDSCORE_AVG_EUPR	RD score: average (by player in the area) of: number of patents (in fractional counting and normalised in interval [0,1]) + number of publications (in fractional counting and normalised in interval [0,1]) + number of EU funded projects (in fractional counting and normalised in interval [0,1])	
FIRM_AIACTIV_TYPE1	Number of Firms with core business in AI but with no AI patent	
FIRM_AIACTIV_TYPE2	Number of Firms with core business in AI and with AI patent	
FIRM_AIACTIV_TYPE3	Number of Firms with no core business in AI but with AI patent	
PERC_F_AGE_00_05	Age of firms: % of firms founded up to 5 years ago	
PERC_F_AGE_05_10	Age of firms: % of firms founded between 5 and 10 years ago	
PERC_F_AGE_11_20	Age of firms: % of firms founded between 11 and 20 years ago	
PERC_F_AGE_21_99	Age of firms: % of firms founded more than 20 years ago	
PERC_F_SIZE_S	Size of firms: % of small firms	
PERC_F_SIZE_M	Size of firms: % of medium-sized firms	
PERC_F_SIZE_L	Size of firms: % of large firms	
PERC_F_SIZE_VL	Size of firms: % of very large firms	
PERC_F_SECTOR_C	Sector of firms: % of firms belonging to sector C	
PERC_F_SECTOR_F	Sector of firms: % of firms belonging to sector F	
PERC_F_SECTOR_G	Sector of firms: % of firms belonging to sector G	
PERC_F_SECTOR_J	Sector of firms: % of firms belonging to sector J	
PERC_F_SECTOR_M	Sector of firms: % of firms belonging to sector M	
PERC_F_SECTOR_REST	Sector of firms: % of firms belonging to any other sector	
		
		
File "AITES2019_AI_subdomains.csv"
Version: v2
Date: 22 jun 2020
Description: This version corrects an error found in the computation of the WORLD SHARE.

_VARIABLE_	_DESCRIPTION_	
GEO_AREA	Name of the country (apart from EU28 that is considered as a single area) where players are located. Location does not imply nationality	
GEO_AREA_CODE	"Code of the country (ISO2, except United Kingdom and Greece, that follow Eurostat code)"	
MACRO_GEO_AREA	Geographic macro area where the players are located
CONTINENT	Geographic continent where the players are located	
TIME_PERIOD	Time period considered for the analysis	
AI_SUBDM	AI subdomains in which the players are active
RCA	Revealed comparative advantage indicator, computed as the ratio between the geo_area share of activities in an AI subdomain over the world average share of activities in the same AI subdomain. Values above 1  in a subdomain reveal a comparative advantage of the geographic area in that subdomain
WORLD_SHARE	World share of a geo_area in a subdomain, computed as the number of activities of the geo_area in a subdomain over the number of worlwide activities in that subdomain
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
